import os
import sys
import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
import argparse
import torch
import torch.nn as nn
from torch_geometric.data import Data as gData
from torch_geometric.loader import DataLoader as gDataLoader
import torch
import torch.nn as nn
import numpy as np
from sklearn.metrics import mean_absolute_error
from models import Sagefusionnet
###############Teststing model on new data#########################
#bestmodel.eval()
# Load the new data from a different CSV file
# 1 read data
new_data_df = pd.read_csv("/content/vols_GM_PPMI_PD_all.csv")
new_data_df2 = pd.read_csv("/content/vols_WM_PPMI_PD_all.csv")
vcols = pd.read_csv( "/content/rois.csv")["roi"].values.tolist() #column values are converted to a Python list

for p in vcols:
    new_data_df[p] = new_data_df[p] / new_data_df["intra_vol"]
    new_data_df2[p] = new_data_df2[p] / new_data_df2["intra_vol"]

# Scale (standardize) the new test data
new_data_df_mean = new_data_df[vcols].mean()
new_data_df_std = new_data_df[vcols].std()
new_data_df2_mean = new_data_df2[vcols].mean()
new_data_df2_std = new_data_df2[vcols].std()

# Standardize the new test data column-wise using their respective mean and std

new_data_df[vcols] = (new_data_df[vcols] - new_data_df_mean) / new_data_df_std
new_data_df2[vcols] = (new_data_df2[vcols] - new_data_df2_mean) / new_data_df2_std
#Load the  edge_index tensor
edge_index = torch.load('edge_index.pt')
# Create data lists for the new data
new_data_dls_test_PPMI = []
#edge_index_print_count = 0
for i in range(new_data_df.shape[0]):
    d = gData()
    T1 = new_data_df.iloc[i][vcols]
    T2 = new_data_df2.iloc[i][vcols]
    DD = pd.concat([T1, T2], axis=1)
    d['x'] = torch.FloatTensor(DD.values.astype(np.float32))
    d['y']   = torch.FloatTensor( new_data_df.iloc[i]["age"].ravel())
    d['edge_index'] = edge_index
    new_data_dls_test_PPMI.append(d)

SAGEFusionNet_model = Sagefusionnet(d=2, dim1=64, r=4,num_nodes=56,dropout_prob=0.15, lambda_aux=0.3)
SAGEFusionNet_model.load_state_dict(torch.load("/content/SAGEFusionNet_trained_model.pth",weights_only=True))
SAGEFusionNet_model.eval()
predictions_PPMI = []
target_values_test_PPMI = []
with torch.no_grad():
    for data in new_data_dls_test_PPMI:
        # Forward pass through the model to get predictions
        output,_ = SAGEFusionNet_model(data)
        target_values = data.y.numpy()
        target_values_test_PPMI.extend(target_values)
        # Process 'output' as needed based on the task
        predictions_PPMI.extend(output.cpu().detach().numpy().flatten())
        
#all_target_values, all_predictions = test_model(model, test_loader)
all_predictions_PPMI  = [round(float(x),1) for x in predictions_PPMI]
all_target_values_PPMI = [round(float(y),1) for y in target_values_test_PPMI]
print("all_predictions_PPMI:",all_predictions_PPMI)
print("all_target_values_PPMI :", all_target_values_PPMI)
MAE=mean_absolute_error(all_predictions_PPMI,all_target_values_PPMI )
print('Eternal test MAE:', round(MAE,2))
