import os

# Define file paths
gm_file = "/content/ALL_ADNI_GM_LPBA40_70_ALL DIGITS.csv"
wm_file = "/content/ALL_ADNI_WM_LPBA40_70_ALL DIGITS.csv"
rois_file = "/content/rois.csv"

# Ensure all files exist
for path in [gm_file, wm_file, rois_file]:
    if not os.path.exists(path):
        raise FileNotFoundError(f" File not found: {path}")

# Build the command string
command = (
    f'python train_GAT_model.pyc '
    f'--gm_file "{gm_file}" '
    f'--wm_file "{wm_file}" '
    f'--rois_file "{rois_file}"'
)

# Print and run the command
print("Starting training...")
os.system(command)
print("Training completed.")
